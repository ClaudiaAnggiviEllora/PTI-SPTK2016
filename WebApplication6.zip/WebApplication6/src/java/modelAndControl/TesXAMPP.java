/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelAndControl;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Ronny Gunadi
 */
public class TesXAMPP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException {
        // TODO code application logic here
        Connection conn = null;
        String driver = "com.mysql.jdbc.Driver";
        String database = "jdbc:mysql://localhost:3306/dbsptk";
        String user = "root";
        String pass = "";
        try {
            Class.forName(driver);
            conn = (Connection) DriverManager.getConnection(database, user, pass);
            System.out.println("Koneksi Berhasil");
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("VendorError: " + e.getErrorCode());
        }
    }
}
