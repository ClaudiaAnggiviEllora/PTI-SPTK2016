/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelAndControl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author laura
 */
public class query {
     PreparedStatement statement;
    Statement stmt;
    ResultSet resultSet;
    
    public static void insertMember(String id, String nama, String telepon, String alamat,
            String passwd)
            throws SQLException {
      PreparedStatement stmt = null;
        String sql = "INSERT INTO tabelcistomers VALUES(?, ?, ?,?)";

        try {
            connection = Koneksi.getConnection();
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, kode);
            stmt.setString(2, nama);
            stmt.setDouble(3, harga);
            stmt.setString(4, level);

            stmt.executeUpdate();

        } catch (SQLException ignore) {
            ignore.printStackTrace();
        }

    }
}
