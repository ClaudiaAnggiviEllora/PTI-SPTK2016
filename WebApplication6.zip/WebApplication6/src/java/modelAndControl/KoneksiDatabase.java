package modelAndControl;

import java.sql.*;

/**
 *
 * @author Bowi
 */

public class KoneksiDatabase {
    String jdbcDriver = "com.mysql.jdbc.Driver";
    String dbURL = "jdbc:mysql://localhost/joging";
    String username = "root";
    String password = "";
    
    public KoneksiDatabase() {
        getConnection();
    }
    
    public Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName(jdbcDriver);
            conn = DriverManager.getConnection(dbURL, username, password);
        } catch (Exception e) {
            System.out.println("Not Connected!");
        }
        return conn;
    }
    
    public static void main(String[] args) {
        KoneksiDatabase conn = new KoneksiDatabase();
    }
}