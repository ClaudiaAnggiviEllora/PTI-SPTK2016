/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PTI;


import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Koneksi {
     private static final String driver = "com.mysql.jdbc.Driver";
    private static final String database = "jdbc:mysql://localhost:8084/sptk";
    private static final String user = "root";
    private static final String password = "";
    
    private Connection connection;        
    private String pesanKesalahan;

    public String getPesanKesalahan() {
        return pesanKesalahan;
    }
    
    public Connection getConnection() throws SQLException{
        Connection conn = null;
        String driver = "com.mysql.jdbc.Driver";
        String database = "jdbc:mysql://localhost:3306/sptk";
        String user = "root";
        String pass = "";
         try {
             
             Class.forName(driver);
             conn = (Connection) DriverManager.getConnection(database, user, pass);
             System.out.println("Koneksi Berhasil");                          
         } catch (ClassNotFoundException ex) {
             Logger.getLogger(Koneksi.class.getName()).log(Level.SEVERE, null, ex);
         }
             return conn;
}
    
     public static void main(String[] args) throws ClassNotFoundException {
        // TODO code application logic here
        Connection conn = null;
        String driver = "com.mysql.jdbc.Driver";
        String database = "jdbc:mysql://localhost:3306/sptk";
        String user = "root";
        String pass = "";
        try {
            Class.forName(driver);
            conn = (Connection) DriverManager.getConnection(database, user, pass);
            System.out.println("Koneksi Berhasil");
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("VendorError: " + e.getErrorCode());
        }
    }
}
